def admin():
    x="THIS IS IT ADMIN"
    return(x)

def cabin():
    y="THIS IS IT CABIN"
    return(y)