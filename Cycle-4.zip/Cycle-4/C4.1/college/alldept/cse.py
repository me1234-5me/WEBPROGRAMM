def admin():
    x="THIS IS CSE ADMIN"
    return(x)

def cabin():
    y="THIS IS CSE CABIN"
    return(y)