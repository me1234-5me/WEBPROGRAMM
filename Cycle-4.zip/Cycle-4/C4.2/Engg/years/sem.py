def staff():
    x="I AM STAFF"
    return (x)

def student():
    y="I AM A STUDENT"
    return(y)