def surfacearea(r):
    return 4*3.14*r*r

def volume(r):
    return 4/3*3.14*r*r*r
