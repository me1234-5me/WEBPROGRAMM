def surfacearea(l,b,h):
    return 2*(l*b+b*h+h*l)

def volume(l,b,h):
    return l*b*h